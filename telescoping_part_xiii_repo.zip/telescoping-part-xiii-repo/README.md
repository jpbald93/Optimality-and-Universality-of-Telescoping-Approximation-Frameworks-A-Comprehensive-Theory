# Telescoping Approximation Frameworks (Part XIII) — Reproducibility Repo

This repository contains **lightweight, self-contained Python code** to reproduce the *illustrative*
numerical examples used in the Part XIII manuscript:

- **Heat equation telescoping**: spatial refinement (finite differences) + temporal refinement (Crank–Nicolson),
  producing incremental errors and log–log plots analogous to Fig. 2.
- **MLMC option pricing (Heston model)**: multilevel Monte Carlo estimator for a European call, producing
  level-difference variance decay and a simple cost comparison analogous to Tables 3–4 and Fig. 3.

> Note: The Part XIII paper is primarily theoretical; these scripts are provided as **illustrations** and
> sanity checks, not as a dependency for any theorem.

## Quick start

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt

# Heat equation example
python scripts/heat_equation_telescoping.py

# MLMC Heston option example
python scripts/mlmc_heston.py
```

Outputs are saved to `outputs/`:
- CSV tables (errors / variances / costs)
- PNG plots

## Reproducibility

- Random seeds are fixed in MLMC script by default.
- Parameters (T, grids, levels, samples) are at the top of each script.

## License

MIT — see `LICENSE`.
