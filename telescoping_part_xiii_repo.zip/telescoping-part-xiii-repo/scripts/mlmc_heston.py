"""
MLMC (Multilevel Monte Carlo) for a European call under the Heston model.

This script demonstrates the telescoping identity:
E[P_L] = E[P_0] + sum_{l=0}^{L-1} E[P_{l+1} - P_l]

We:
- simulate coupled Heston paths using Euler–Maruyama (full truncation for variance)
- estimate the variance of level differences Var(P_l - P_{l-1})
- build a simple MLMC estimator and compare rough costs to standard MC

Outputs:
- outputs/mlmc_heston_variance_table.csv
- outputs/mlmc_cost_table.csv
- outputs/mlmc_variance_plot.png
- outputs/mlmc_cost_plot.png
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)

def heston_payoff_paths(S0, K, r, T, kappa, theta, sigma, rho, V0, dt, n_paths, seed=1234):
    """
    Simulate payoff samples for a European call using Euler scheme with full truncation variance.
    Returns payoffs discounted.
    """
    rng = np.random.default_rng(seed)
    n_steps = int(round(T / dt))
    dt = T / n_steps  # adjust
    sqrt_dt = np.sqrt(dt)

    S = np.full(n_paths, S0, dtype=float)
    V = np.full(n_paths, V0, dtype=float)

    for _ in range(n_steps):
        z1 = rng.standard_normal(n_paths)
        z2 = rng.standard_normal(n_paths)
        w1 = z1
        w2 = rho * z1 + np.sqrt(max(1e-12, 1.0 - rho*rho)) * z2

        V_pos = np.maximum(V, 0.0)
        V = V + kappa*(theta - V_pos)*dt + sigma*np.sqrt(V_pos)*sqrt_dt*w2
        V = np.maximum(V, 0.0)

        S = S * np.exp((r - 0.5*V_pos)*dt + np.sqrt(V_pos)*sqrt_dt*w1)

    payoff = np.maximum(S - K, 0.0)
    return np.exp(-r*T) * payoff

def coupled_level_diff(S0, K, r, T, kappa, theta, sigma, rho, V0, level, n_paths, seed=1234):
    """
    Coupled fine/coarse simulation for MLMC:
    - level l uses dt = T / 2^l
    - level l-1 uses dt = T / 2^{l-1} (twice dt)
    We couple by using shared Brownian increments: coarse increment = sum of two fine increments.
    Returns sample differences (P_l - P_{l-1}). For level=0, return P_0 samples.
    """
    rng = np.random.default_rng(seed + 1000*level)
    if level == 0:
        dt = T / 1.0
        return heston_payoff_paths(S0, K, r, T, kappa, theta, sigma, rho, V0, dt, n_paths, seed=seed+7)

    n_fine = 2**level
    dt_f = T / n_fine
    dt_c = 2*dt_f
    sqrt_dt_f = np.sqrt(dt_f)

    # state
    Sf = np.full(n_paths, S0, dtype=float)
    Vf = np.full(n_paths, V0, dtype=float)
    Sc = np.full(n_paths, S0, dtype=float)
    Vc = np.full(n_paths, V0, dtype=float)

    # simulate with coupling: two fine steps per coarse step
    for _ in range(2**(level-1)):
        # generate two sets of fine normals per coarse step
        z1a = rng.standard_normal(n_paths)
        z2a = rng.standard_normal(n_paths)
        z1b = rng.standard_normal(n_paths)
        z2b = rng.standard_normal(n_paths)

        # correlate per fine step
        w1a = z1a
        w2a = rho*z1a + np.sqrt(max(1e-12, 1-rho*rho))*z2a
        w1b = z1b
        w2b = rho*z1b + np.sqrt(max(1e-12, 1-rho*rho))*z2b

        # coarse increments are sums
        w1c = (w1a + w1b) / np.sqrt(2.0)
        w2c = (w2a + w2b) / np.sqrt(2.0)

        # --- fine step A
        Vp = np.maximum(Vf, 0.0)
        Vf = Vf + kappa*(theta - Vp)*dt_f + sigma*np.sqrt(Vp)*sqrt_dt_f*w2a
        Vf = np.maximum(Vf, 0.0)
        Sf = Sf * np.exp((r - 0.5*Vp)*dt_f + np.sqrt(Vp)*sqrt_dt_f*w1a)

        # --- fine step B
        Vp = np.maximum(Vf, 0.0)
        Vf = Vf + kappa*(theta - Vp)*dt_f + sigma*np.sqrt(Vp)*sqrt_dt_f*w2b
        Vf = np.maximum(Vf, 0.0)
        Sf = Sf * np.exp((r - 0.5*Vp)*dt_f + np.sqrt(Vp)*sqrt_dt_f*w1b)

        # --- coarse step
        Vp = np.maximum(Vc, 0.0)
        Vc = Vc + kappa*(theta - Vp)*dt_c + sigma*np.sqrt(Vp)*np.sqrt(dt_c)*w2c
        Vc = np.maximum(Vc, 0.0)
        Sc = Sc * np.exp((r - 0.5*Vp)*dt_c + np.sqrt(Vp)*np.sqrt(dt_c)*w1c)

    Pf = np.exp(-r*T) * np.maximum(Sf - K, 0.0)
    Pc = np.exp(-r*T) * np.maximum(Sc - K, 0.0)
    return Pf - Pc

def save_csv(path, header, data):
    np.savetxt(path, data, delimiter=",", header=header, comments="", fmt="%.10g")

def plot_loglog(x, y, xlabel, ylabel, outpath: Path, ref_slope=None):
    plt.figure()
    plt.loglog(x, y, marker="o")
    if ref_slope is not None:
        x0, y0 = x[-1], y[-1]
        xx = np.array([x[0], x[-1]])
        yy = y0 * (xx / x0) ** ref_slope
        plt.loglog(xx, yy, linestyle="--")
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(True, which="both")
    plt.tight_layout()
    plt.savefig(outpath, dpi=180)
    plt.close()

def main():
    # Parameters (match the paper's illustrative numbers)
    S0 = 100.0
    K = 100.0
    r = 0.05
    T = 1.0
    kappa = 2.0
    theta = 0.04
    sigma = 0.3
    rho = -0.7
    V0 = theta

    # Levels and samples for variance estimation (small & fast; adjust upward if desired)
    levels = list(range(0, 6))
    n_paths_base = 20000
    seed = 2026

    var_rows = []
    for l in levels:
        n_paths = max(2000, n_paths_base // (2**l))
        diffs = coupled_level_diff(S0, K, r, T, kappa, theta, sigma, rho, V0, l, n_paths, seed=seed)
        var = float(np.var(diffs, ddof=1))
        cost_per_sample = 2**l  # crude proxy: finer level costs more
        var_rows.append([l, T/(2**l), n_paths, var, cost_per_sample])

    var_tbl = np.array(var_rows, dtype=float)
    save_csv(OUT / "mlmc_heston_variance_table.csv",
             "level,dt,n_paths,var_diff,cost_per_sample_proxy", var_tbl)

    # Plot variance decay vs level
    plot_loglog(var_tbl[:,0] + 1, var_tbl[:,3], "Level (l+1)", "Var(P_l - P_{l-1})",
                OUT / "mlmc_variance_plot.png", ref_slope=-2.0)

    # Rough cost comparison for target eps (heuristic, not an optimizer)
    eps_list = np.array([0.1, 0.05, 0.025, 0.0125], dtype=float)
    # Standard MC cost ~ eps^{-3} proxy, MLMC cost ~ eps^{-2} log(1/eps) proxy
    cost_std = eps_list ** (-3)
    cost_mlmc = eps_list ** (-2) * np.log(1/eps_list)
    cost_tbl = np.column_stack([eps_list, cost_std, cost_mlmc, cost_std/cost_mlmc])
    save_csv(OUT / "mlmc_cost_table.csv", "eps,cost_std_proxy,cost_mlmc_proxy,speedup_proxy", cost_tbl)

    # Plot costs
    plt.figure()
    plt.loglog(eps_list, cost_std, marker="o", label="Std MC (proxy)")
    plt.loglog(eps_list, cost_mlmc, marker="o", label="MLMC (proxy)")
    plt.gca().invert_xaxis()
    plt.xlabel("Target accuracy ε")
    plt.ylabel("Computational cost (proxy)")
    plt.grid(True, which="both")
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUT / "mlmc_cost_plot.png", dpi=180)
    plt.close()

    print("Wrote outputs to", OUT.resolve())

if __name__ == "__main__":
    main()
