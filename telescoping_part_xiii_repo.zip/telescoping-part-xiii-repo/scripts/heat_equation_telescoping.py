"""
Heat equation telescoping illustration.

We solve u_t = u_xx on [0,1] with Dirichlet boundary conditions u(t,0)=u(t,1)=0
and initial condition u(0,x)=sin(pi x). Exact solution: u(t,x)=exp(-pi^2 t) sin(pi x).

We compute:
- Spatial telescoping increments by comparing coarse vs refined finite-difference steady spatial discretizations
  for the solution snapshot at time T (computed on a very fine time step to reduce time error).
- Temporal telescoping increments by Crank–Nicolson time stepping on a fixed fine spatial grid and comparing
  n vs 2n time steps.

Outputs:
- outputs/heat_spatial_table.csv
- outputs/heat_temporal_table.csv
- outputs/heat_spatial_plot.png
- outputs/heat_temporal_plot.png
"""

from __future__ import annotations
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)

def exact_solution(x: np.ndarray, T: float) -> np.ndarray:
    return np.exp(-(np.pi**2)*T) * np.sin(np.pi*x)

def crank_nicolson_heat(u0: np.ndarray, dx: float, T: float, nsteps: int) -> np.ndarray:
    """
    Crank–Nicolson for u_t = u_xx with Dirichlet boundaries on interior grid points.
    u0 includes only interior points (excluding boundaries).
    """
    m = u0.size
    dt = T / nsteps
    r = dt / (dx*dx)

    # Tridiagonal matrices: (I - r/2 A) u^{n+1} = (I + r/2 A) u^n, where A is second-diff matrix.
    # A has -2 on diag, 1 on off-diags.
    diag = (1 + r) * np.ones(m)
    off = (-r/2) * np.ones(m-1)
    # Left matrix: L = I - (r/2)A => diag = 1 + r, off = -r/2
    L_diag = diag.copy()
    L_off = off.copy()

    # Right matrix: R = I + (r/2)A => diag = 1 - r, off = r/2
    R_diag = (1 - r) * np.ones(m)
    R_off = (r/2) * np.ones(m-1)

    def tridiag_matvec(d, o, v):
        y = d * v
        y[:-1] += o * v[1:]
        y[1:] += o * v[:-1]
        return y

    def solve_tridiag(d, o, b):
        # Thomas algorithm for symmetric tri-diagonal with diag d and off o (length m-1)
        n = b.size
        cp = np.empty(n-1)
        dp = np.empty(n)
        cp[0] = o[0]/d[0]
        dp[0] = b[0]/d[0]
        for i in range(1, n-1):
            denom = d[i] - o[i-1]*cp[i-1]
            cp[i] = o[i]/denom
            dp[i] = (b[i] - o[i-1]*dp[i-1])/denom
        denom = d[n-1] - o[n-2]*cp[n-2]
        dp[n-1] = (b[n-1] - o[n-2]*dp[n-2])/denom
        x = np.empty(n)
        x[n-1] = dp[n-1]
        for i in reversed(range(n-1)):
            x[i] = dp[i] - cp[i]*x[i+1]
        return x

    u = u0.copy()
    for _ in range(nsteps):
        b = tridiag_matvec(R_diag, R_off, u)
        u = solve_tridiag(L_diag, -L_off, b)  # note: Thomas expects off-diag values; signs already in L_off
    return u

def spatial_telescoping(T: float = 0.1, base_levels=(3,4,5,6,7), nsteps_fine=20000):
    """
    Compute spatial incremental errors by comparing solutions at grid sizes h=2^{-n}.
    Time error reduced by using a large fixed number of steps.
    """
    rows = []
    prev_u = None
    prev_h = None

    for n in base_levels:
        h = 2.0**(-n)
        # Interior points
        x = np.arange(1, int(1/h)) * h
        u0 = np.sin(np.pi * x)
        # Use CN with many steps to reduce time error relative to spatial
        uT = crank_nicolson_heat(u0, h, T, nsteps_fine)

        u_exact = exact_solution(x, T)
        err = np.linalg.norm(u_exact - uT) / np.sqrt(u_exact.size)

        inc_err = np.nan
        rate = np.nan
        if prev_u is not None:
            # Compare with refined grid at n (current) and previous n-1 by restricting current to coarse points
            # If grids are powers of 2, coarse interior points are every other point
            uT_restricted = uT[1::2]  # matches x at spacing 2h
            inc_err = np.linalg.norm(uT_restricted - prev_u) / np.sqrt(prev_u.size)
            rate = np.log(inc_err / rows[-1][3]) / np.log(0.5) if not np.isnan(rows[-1][3]) else np.nan

        rows.append([n, h, err, inc_err, rate])
        prev_u = uT
        prev_h = h

    return np.array(rows, dtype=float)

def temporal_telescoping(T: float = 0.1, h_fixed=2**(-8), steps=(8,16,32,64,128)):
    """
    Compute temporal telescoping increments by comparing n vs 2n CN steps on fixed fine spatial grid.
    """
    # Fixed spatial grid
    h = float(h_fixed)
    x = np.arange(1, int(1/h)) * h
    u0 = np.sin(np.pi * x)
    u_exact = exact_solution(x, T)

    rows = []
    prev_u = None
    for n in steps:
        uT = crank_nicolson_heat(u0, h, T, n)
        err = np.linalg.norm(u_exact - uT) / np.sqrt(u_exact.size)
        inc_err = np.nan
        rate = np.nan
        if prev_u is not None:
            inc_err = np.linalg.norm(uT - prev_u) / np.sqrt(prev_u.size)
            rate = np.log(inc_err / rows[-1][3]) / np.log(2.0) if not np.isnan(rows[-1][3]) else np.nan
        rows.append([n, T/n, err, inc_err, rate])
        prev_u = uT
    return np.array(rows, dtype=float)

def save_table(path: Path, header: str, data: np.ndarray):
    np.savetxt(path, data, delimiter=",", header=header, comments="", fmt="%.10g")

def plot_loglog(x, y, xlabel, ylabel, outpath: Path, ref_slope=None):
    plt.figure()
    plt.loglog(x, y, marker="o")
    if ref_slope is not None:
        # draw reference line through last point
        x0, y0 = x[-1], y[-1]
        xx = np.array([x[0], x[-1]])
        yy = y0 * (xx / x0) ** ref_slope
        plt.loglog(xx, yy, linestyle="--")
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.grid(True, which="both")
    plt.tight_layout()
    plt.savefig(outpath, dpi=180)
    plt.close()

def main():
    T = 0.1

    spatial = spatial_telescoping(T=T)
    save_table(OUT / "heat_spatial_table.csv", "level_n,h,err_L2,inc_err_L2,rate", spatial)

    # plot increment vs level (use h as proxy)
    n = spatial[:,0]
    inc = spatial[:,3]
    mask = ~np.isnan(inc)
    plot_loglog(2.0**n[mask], inc[mask], "Refinement factor (2^n)", "Incremental error ||u_h - u_{2h}||_2",
                OUT / "heat_spatial_plot.png", ref_slope=-2.0)

    temporal = temporal_telescoping(T=T)
    save_table(OUT / "heat_temporal_table.csv", "nsteps,dt,err_L2,inc_err_L2,rate", temporal)

    nsteps = temporal[:,0]
    inc_t = temporal[:,3]
    mask = ~np.isnan(inc_t)
    plot_loglog(nsteps[mask], inc_t[mask], "Time steps n", "Incremental error ||u_{2n} - u_n||_2",
                OUT / "heat_temporal_plot.png", ref_slope=-3.0)

    print("Wrote outputs to", OUT.resolve())

if __name__ == "__main__":
    main()
